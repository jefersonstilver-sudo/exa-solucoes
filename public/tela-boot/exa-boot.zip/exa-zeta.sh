#!/system/bin/sh
# EXA · diagnóstico do Zeta (roda como root): animação de boot, logo do bootloader, escala de animação
O=/data/local/tmp/exa-diag.txt
{
echo "== boot.mp4"; ls -l /data/local/boot.mp4 /system/media/boot.mp4
echo "== animacoes"; settings get global animator_duration_scale; settings get global transition_animation_scale; settings get global window_animation_scale
echo "== particoes"; ls -l /dev/block/by-name/
mkdir -p /data/local/tmp/bl
for p in bootloader bootloader_a bootloader_b boot-resource; do
  if [ -e /dev/block/by-name/$p ]; then
    if mount -t vfat -o ro /dev/block/by-name/$p /data/local/tmp/bl 2>/dev/null; then
      echo "== $p"; ls -laR /data/local/tmp/bl | head -60
      for f in /data/local/tmp/bl/*.bmp /data/local/tmp/bl/*/*.bmp; do [ -f "$f" ] && { echo "-- $f"; od -A d -t u1 -N 40 "$f" | head -3; }; done
      umount /data/local/tmp/bl
    else echo "== $p: nao montou"; fi
  fi
done
echo "== props"; getprop | grep -iE 'logo|bootanim|disp' | head -20
} > $O 2>&1
chmod 666 $O
