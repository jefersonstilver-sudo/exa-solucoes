# -*- coding: utf-8 -*-
"""
EXA 2.0 — player v10: o próprio player garante o "padrão EXA" no NUC (sem terminal, via OTA).

Roda em segundo plano dentro do atualizador (thread daemon), 60 s depois de iniciar e depois a cada 6 h:
  1. ~/.exa_saude.json com o código da tela (tela_id do player)
  2. coletor de saúde (exa_saude.py) e vigia de rede (exa_vigia_rede.sh) — regrava só se mudou
  3. bloqueios: desligamento programado (poweroff/halt), packagekit e atualizações automáticas do apt
  4. agendamentos no crontab do usuário (coletor a cada 15 min, vigia a cada 5 min), preservando as outras linhas
  5. primeira leitura do coletor logo após instalar/atualizar
  6. registra o resultado em ~/.exa_padrao.json (o coletor envia isso ao sistema)
Nunca levanta exceção para fora, nunca para nem reinicia o player.
"""
import fcntl
import json
import os
import subprocess
import threading
import time

VERSAO = "padrao-v2"
APP = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
HOME = os.path.expanduser("~")
ESTADO = os.path.join(HOME, ".exa_padrao.json")
CONF_SAUDE = os.path.join(HOME, ".exa_saude.json")
BLOQUEAR = ["poweroff.target", "halt.target", "packagekit.service", "apt-daily.timer",
            "apt-daily-upgrade.timer", "update-notifier-download.timer", "update-notifier-motd.timer"]

COLETOR = '# -*- coding: utf-8 -*-\n"""\nEXA 2.0 — Coletor de saúde do NUC ("auditoria v7", automática).\n\nRoda a cada 15 min pelo cron do usuário (instalado por instalar_saude_no_nuc.sh), SEPARADO do player:\n  - só LÊ o sistema (nada é alterado, nada é reiniciado);\n  - prioridade mínima de CPU e disco (nice 19 / ionice idle) e limite total de 90 s (timeout no cron);\n  - cada medição tem limite próprio; se uma falhar, as outras seguem;\n  - se a internet estiver fora, apenas não envia (tenta de novo no próximo ciclo).\n\nEnvia para o ExaSistema (função telas_registrar_saude), a mesma porta que o player usa para o heartbeat.\nO teste de velocidade de download (5 MB) roda só 1x por dia.\n"""\nimport json\nimport os\nimport re\nimport shutil\nimport socket\nimport subprocess\nimport sys\nimport time\nimport urllib.request\n\nAPP = os.path.expanduser("~/Documentos/appUbuntu")\nCONF = os.path.expanduser("~/.exa_saude.json")      # {"cliente_id": "bc17"} gravado na instalação\nESTADO = os.path.expanduser("~/.exa_saude_estado.json")\nVERSAO_COLETOR = "saude-v6"\nAPI_TELAS = "18.228.252.149"\n\n\ndef sh(cmd, timeout=8, env=None):\n    try:\n        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout, env=env)\n        return r.stdout.strip()\n    except Exception:\n        return ""\n\n\ndef ler(caminho, padrao=""):\n    try:\n        with open(caminho) as f:\n            return f.read().strip()\n    except Exception:\n        return padrao\n\n\ndef env_do_player():\n    vals = {}\n    for linha in ler(os.path.join(APP, ".env")).splitlines():\n        linha = linha.strip()\n        if not linha or linha.startswith("#") or "=" not in linha:\n            continue\n        k, v = linha.split("=", 1)\n        vals[k.strip()] = v.strip().strip(\'"\').strip("\'")\n    return vals\n\n\ndef temperatura():\n    melhor = None\n    for zona in sorted(os.listdir("/sys/class/thermal")) if os.path.isdir("/sys/class/thermal") else []:\n        if not zona.startswith("thermal_zone"):\n            continue\n        t = ler("/sys/class/thermal/%s/temp" % zona)\n        tipo = ler("/sys/class/thermal/%s/type" % zona)\n        try:\n            c = int(t) / 1000.0\n        except Exception:\n            continue\n        if 5 < c < 125 and (melhor is None or c > melhor[0]):\n            melhor = (c, tipo)\n    if melhor is None:\n        out = sh("sensors 2>/dev/null")\n        nums = [float(x) for x in re.findall(r"\\+(\\d+\\.\\d)°C", out)]\n        if nums:\n            melhor = (max(nums), "sensors")\n    return (round(melhor[0], 1), melhor[1]) if melhor else (None, None)\n\n\ndef memoria():\n    info = {}\n    for linha in ler("/proc/meminfo").splitlines():\n        p = linha.split()\n        if len(p) >= 2:\n            info[p[0].rstrip(":")] = int(p[1])\n    tot, disp = info.get("MemTotal", 0), info.get("MemAvailable", 0)\n    st, sf = info.get("SwapTotal", 0), info.get("SwapFree", 0)\n    return {\n        "ram_total_gb": round(tot / 1048576, 1) if tot else None,\n        "ram_uso_pct": round(100 * (tot - disp) / tot) if tot else None,\n        "swap_uso_pct": round(100 * (st - sf) / st) if st else 0,\n    }\n\n\ndef ping(host, n=10):\n    out = sh("ping -n -q -c %d -i 0.3 -W 1 %s 2>/dev/null" % (n, host), timeout=n + 6)\n    perda = re.search(r"(\\d+(?:\\.\\d+)?)% packet loss", out)\n    rtt = re.search(r"= ([\\d.]+)/([\\d.]+)/([\\d.]+)/([\\d.]+) ms", out)\n    return {\n        "perda_pct": float(perda.group(1)) if perda else 100.0,\n        "lat_ms": float(rtt.group(2)) if rtt else None,\n        "lat_max_ms": float(rtt.group(3)) if rtt else None,\n        "jitter_ms": float(rtt.group(4)) if rtt else None,\n    }\n\n\ndef tcp(host, porta, n=5):\n    """Servidor das telas não responde ping (firewall da AWS): mede abrindo conexão na porta da API."""\n    tempos, falhas = [], 0\n    for _ in range(n):\n        t0 = time.time()\n        try:\n            c = socket.create_connection((host, porta), timeout=3)\n            c.close()\n            tempos.append((time.time() - t0) * 1000)\n        except Exception:\n            falhas += 1\n        time.sleep(0.2)\n    return {\n        "perda_pct": round(100.0 * falhas / n, 1),\n        "lat_ms": round(sum(tempos) / len(tempos), 1) if tempos else None,\n        "lat_max_ms": round(max(tempos), 1) if tempos else None,\n        "metodo": "tcp",\n    }\n\n\ndef rede():\n    d = {}\n    rota = sh("ip -4 route show default 2>/dev/null").splitlines()\n    m = re.search(r"default via (\\S+) dev (\\S+)", rota[0]) if rota else None\n    if not m:\n        d["sem_rota"] = True\n        return d\n    gw, iface = m.group(1), m.group(2)\n    d["gateway"], d["iface"] = gw, iface\n    sem_fio = os.path.isdir("/sys/class/net/%s/wireless" % iface) or os.path.exists("/sys/class/net/%s/phy80211" % iface)\n    d["tipo"] = "wifi" if sem_fio else "cabo"\n    vel = ler("/sys/class/net/%s/speed" % iface)\n    if vel.lstrip("-").isdigit() and int(vel) > 0:\n        d["link_mbps"] = int(vel)\n    if sem_fio:\n        lk = sh("iw dev %s link 2>/dev/null" % iface)\n        f = re.search(r"freq: (\\d+)", lk)\n        s = re.search(r"signal: (-?\\d+) dBm", lk)\n        b = re.search(r"tx bitrate: ([\\d.]+) MBit", lk)\n        ss = re.search(r"SSID: (.+)", lk)\n        if f:\n            mhz = int(f.group(1))\n            d["wifi_mhz"] = mhz\n            d["wifi_banda"] = "5 GHz" if mhz >= 4900 else "2.4 GHz"\n        if s:\n            d["wifi_sinal_dbm"] = int(s.group(1))\n        if b:\n            d["wifi_taxa_mbps"] = float(b.group(1))\n        if ss:\n            d["wifi_ssid"] = ss.group(1).strip()[:40]\n    d["gw"] = ping(gw)\n    d["internet"] = ping("8.8.8.8")\n    d["api_telas"] = tcp(API_TELAS, 8000)\n    try:\n        with urllib.request.urlopen("https://api.ipify.org", timeout=6) as r:\n            d["ip_publico"] = r.read(64).decode().strip()\n    except Exception:\n        pass\n    try:\n        socket.setdefaulttimeout(5)\n        socket.gethostbyname("iwlscwsenzgyylopnwpu.supabase.co")\n        d["dns_ok"] = True\n    except Exception:\n        d["dns_ok"] = False\n    return d\n\n\ndef velocidade_download(estado):\n    """5 MB, no máximo 1x a cada 20 h."""\n    if time.time() - estado.get("ultimo_speedtest", 0) < 20 * 3600:\n        return estado.get("download_mbps")\n    try:\n        t0 = time.time()\n        req = urllib.request.Request("https://speed.cloudflare.com/__down?bytes=5000000", headers={"User-Agent": "exa-saude"})\n        n = 0\n        with urllib.request.urlopen(req, timeout=40) as r:\n            while True:\n                bloco = r.read(65536)\n                if not bloco:\n                    break\n                n += len(bloco)\n        seg = max(time.time() - t0, 0.001)\n        mbps = round(n * 8 / seg / 1e6, 1)\n        estado["ultimo_speedtest"] = time.time()\n        estado["download_mbps"] = mbps\n        return mbps\n    except Exception:\n        estado["ultimo_speedtest"] = time.time() - 18 * 3600  # tenta de novo em ~2 h\n        return None\n\n\ndef monitor():\n    env = dict(os.environ)\n    env.setdefault("DISPLAY", ":0")\n    env.setdefault("XAUTHORITY", os.path.expanduser("~/.Xauthority"))\n    d = {}\n    xr = sh("xrandr --query 2>/dev/null", timeout=6, env=env)\n    if xr:\n        conectadas = re.findall(r"^(\\S+) connected(?: primary)? (\\d+x\\d+)?", xr, re.M)\n        d["saidas_conectadas"] = [c[0] for c in conectadas]\n        d["resolucao"] = next((c[1] for c in conectadas if c[1]), None)\n        d["monitor_conectado"] = bool(conectadas)\n    xs = sh("xset q 2>/dev/null", timeout=6, env=env)\n    if "Monitor is" in xs:\n        d["monitor_ligado"] = "Monitor is On" in xs\n    return d\n\n\ndef versao_player():\n    m = re.search(r\'APP_VERSAO\\s*=\\s*"([^"]+)"\', ler(os.path.join(APP, "atualizadores", "sistema.py")))\n    return m.group(1) if m else (ler(os.path.join(APP, "version_app.txt")) or None)\n\n\ndef cpu():\n    """Uso real de CPU em 2 s e os processos que mais consomem (explica carga alta)."""\n    def amostra():\n        v = [int(x) for x in ler("/proc/stat").splitlines()[0].split()[1:]]\n        ocioso = v[3] + (v[4] if len(v) > 4 else 0)\n        return sum(v), ocioso\n    try:\n        t1, o1 = amostra()\n        time.sleep(2)\n        t2, o2 = amostra()\n        uso = round(100 * (1 - (o2 - o1) / max(t2 - t1, 1)))\n    except Exception:\n        uso = None\n    top = []\n    for linha in sh("ps -eo pcpu,pmem,comm --sort=-pcpu --no-headers 2>/dev/null | head -n 5").splitlines():\n        p = linha.split(None, 2)\n        if len(p) == 3:\n            top.append({"cpu": float(p[0]), "mem": float(p[1]), "proc": p[2][:30]})\n    io = sh("cat /proc/pressure/io 2>/dev/null | head -n1")\n    m = re.search(r"avg60=([\\d.]+)", io)\n    return {"cpu_uso_pct": uso, "top": top, "io_espera_pct": float(m.group(1)) if m else None}\n\n\ndef player():\n    procs = sh("pgrep -af \'python\' 2>/dev/null")\n    d = {\n        "main_rodando": "main.py" in procs,\n        "atualizador_rodando": "atualizador.py" in procs,\n        "app_versao": versao_player(),\n    }\n    pid = sh("pgrep -of \'main.py\'")\n    if pid.isdigit():\n        et = sh("ps -o etimes= -p %s" % pid)\n        if et.strip().isdigit():\n            d["main_ha_min"] = int(et) // 60\n    pasta = os.path.join(APP, "cache", "Propagandas")\n    try:\n        arqs = [f for f in os.listdir(pasta) if not f.endswith(".part")]\n        d["videos_no_cache"] = len(arqs)\n        d["cache_mb"] = round(sum(os.path.getsize(os.path.join(pasta, f)) for f in arqs) / 1048576)\n    except Exception:\n        pass\n    # disco aceita escrita? (disco "somente leitura" trava o player sem avisar)\n    teste = os.path.join(APP, ".exa_saude_teste")\n    try:\n        with open(teste, "w") as f:\n            f.write("ok")\n        os.remove(teste)\n        d["disco_gravavel"] = True\n    except Exception:\n        d["disco_gravavel"] = False\n    return d\n\n\ndef sistema():\n    d = {}\n    try:\n        d["uptime_h"] = round(float(ler("/proc/uptime", "0").split()[0]) / 3600, 1)\n    except Exception:\n        pass\n    try:\n        d["load1"] = round(os.getloadavg()[0], 2)\n    except Exception:\n        pass\n    d["cores"] = os.cpu_count()\n    du = shutil.disk_usage("/")\n    d["disco_total_gb"] = round(du.total / 1e9)\n    d["disco_uso_pct"] = round(100 * du.used / du.total)\n    d.update(memoria())\n    d["ntp_ok"] = sh("timedatectl show -p NTPSynchronized --value 2>/dev/null") == "yes"\n    # desligamento programado da 01:00 (cron do root): só é seguro com poweroff/halt mascarados\n    d["poweroff_mascarado"] = sh("systemctl is-enabled poweroff.target 2>/dev/null") == "masked"\n    boots = sh("journalctl --list-boots --no-pager 2>/dev/null | tail -n 30", timeout=10)\n    if boots:\n        agora = time.time()\n        n = 0\n        for linha in boots.splitlines():\n            m = re.search(r"(\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2})", linha)\n            if m:\n                try:\n                    t = time.mktime(time.strptime(m.group(1), "%Y-%m-%d %H:%M:%S"))\n                    if agora - t < 86400:\n                        n += 1\n                except Exception:\n                    pass\n        d["boots_24h"] = n\n    d["hostname"] = socket.gethostname()\n    d["produto"] = ler("/sys/class/dmi/id/product_name") or None\n    d["fabricante"] = ler("/sys/class/dmi/id/sys_vendor") or None\n    d["cpu"] = next((l.split(":", 1)[1].strip() for l in ler("/proc/cpuinfo").splitlines() if l.startswith("model name")), None)\n    return d\n\n\ndef vigia():\n    """Vigia de rede (exa_vigia_rede.sh): eventos dos últimos 7 dias + estado do cabo."""\n    d = {"instalado": "exa_vigia_rede.sh" in sh("crontab -l 2>/dev/null")}\n    try:\n        d["falhas_agora"] = int(ler(os.path.expanduser("~/.exa_vigia/falhas"), "0") or 0)\n    except Exception:\n        d["falhas_agora"] = 0\n    linhas = ler(os.path.expanduser("~/.exa_vigia/vigia.log")).splitlines()\n    limite = time.strftime("%Y-%m-%d", time.localtime(time.time() - 7 * 86400))\n    rec = [l for l in linhas if l[:10] >= limite]\n    d["reboots_7d"] = sum("REINICIANDO O NUC" in l for l in rec)\n    d["rede_reiniciada_7d"] = sum("reiniciando a rede" in l for l in rec)\n    d["sem_rede_7d"] = sum("SEM REDE" in l for l in rec)\n    d["operadora_fora_7d"] = sum("operadora" in l for l in rec)\n    d["eventos"] = [l[:140] for l in rec[-8:]]\n    for dev in sorted(os.listdir("/sys/class/net")):\n        if dev.startswith(("en", "eth")):\n            b = "/sys/class/net/" + dev\n            d["cabo"] = {"placa": dev, "sinal": ler(b + "/carrier") == "1", "velocidade_mbps": ler(b + "/speed") or None,\n                         "driver": os.path.basename(os.path.realpath(b + "/device/driver")) if os.path.exists(b + "/device/driver") else None,\n                         "erros_rx": ler(b + "/statistics/rx_errors") or None}\n            break\n    return d\n\n\ndef identidade():\n    """Um prédio pode ter 2+ NUCs com o mesmo código de tela: cada NUC se identifica pelo ID do AnyDesk\n    (o mesmo do painel de monitoramento) ou, sem ele, pelo machine-id."""\n    ad = sh("anydesk --get-id 2>/dev/null", timeout=8)\n    ad = ad if ad.isdigit() else ""\n    mid = ler("/etc/machine-id")[:12]\n    return ad, (ad or mid or socket.gethostname())\n\n\ndef enviar(payload, env):\n    url = (env.get("SUPABASE_URL") or "").rstrip("/")\n    chave = env.get("SUPABASE_KEY") or env.get("SUPABASE_ANON_KEY") or env.get("SUPABASE_SERVICE_KEY") or ""\n    if not url or not chave:\n        print("sem SUPABASE_URL/chave no .env do player")\n        return False\n    req = urllib.request.Request(\n        url + "/rest/v1/rpc/telas_registrar_saude",\n        data=json.dumps({"p": payload}).encode(),\n        headers={"apikey": chave, "Authorization": "Bearer " + chave, "Content-Type": "application/json"},\n        method="POST",\n    )\n    try:\n        with urllib.request.urlopen(req, timeout=15) as r:\n            return 200 <= r.status < 300\n    except Exception as e:\n        print("envio falhou: %s" % e)\n        return False\n\n\ndef main():\n    conf = {}\n    try:\n        conf = json.loads(ler(CONF, "{}"))\n    except Exception:\n        pass\n    cliente = conf.get("cliente_id")\n    if not cliente:\n        print("sem cliente_id em %s" % CONF)\n        return 1\n    estado = {}\n    try:\n        estado = json.loads(ler(ESTADO, "{}"))\n    except Exception:\n        pass\n    t, fonte = temperatura()\n    ad, nuc = identidade()\n    payload = {"cliente_id": cliente, "nuc_id": nuc, "anydesk_id": ad or None, "coletor": VERSAO_COLETOR,\n               "coletado_em": int(time.time()), "temp_c": t, "temp_fonte": fonte}\n    for nome, fn in (("sistema", sistema), ("cpu", cpu), ("rede", rede), ("monitor", monitor), ("player", player), ("vigia", vigia)):\n        try:\n            payload[nome] = fn()\n        except Exception as e:\n            payload[nome] = {"erro": str(e)[:120]}\n    payload["download_mbps"] = velocidade_download(estado)\n    try:  # v10: o que o próprio player garantiu (padrão EXA)\n        pd = json.loads(ler(os.path.expanduser("~/.exa_padrao.json"), "{}"))\n        payload["padrao"] = {k: pd.get(k) for k in ("versao", "quando", "ok", "itens", "erros")}\n    except Exception:\n        pass\n    ok = enviar(payload, env_do_player())\n    try:\n        with open(ESTADO, "w") as f:\n            json.dump(estado, f)\n    except Exception:\n        pass\n    if "--mostrar" in sys.argv:\n        print(json.dumps(payload, ensure_ascii=False, indent=1))\n    print("ENVIADO" if ok else "NAO ENVIADO")\n    return 0\n\n\nif __name__ == "__main__":\n    sys.exit(main())\n'

VIGIA = '#!/bin/bash\n# EXA 2.0 — vigia de rede (vigia-v1). Roda pelo crontab do usuário exa a cada 5 min.\n# Motivo: Foz Residence 23/10 — no boot das 02:35 a placa Realtek (r8169) não iniciou o PHY,\n# o cabo nunca subiu e o NUC ficou 5 dias "ligado e mudo" até alguém apertar o botão.\n# Regras:\n#  - internet ok                      -> nada\n#  - internet fora, gateway responde  -> problema da operadora/antena: só registra, NÃO reinicia\n#  - nem o gateway responde           -> problema no NUC: 2ª falha (10 min) reinicia a rede;\n#                                        4ª falha (20 min) reinicia o NUC (no máx. 1x a cada 2 h e 4x por dia,\n#                                        e só se o NUC estiver ligado há mais de 20 min)\n# Teste sem agir:  bash exa_vigia_rede.sh --teste\nEST="$HOME/.exa_vigia"; mkdir -p "$EST"; LOG="$EST/vigia.log"\nTESTE=0; [ "$1" = "--teste" ] && TESTE=1\nagora=$(date +%s); up=$(cut -d. -f1 /proc/uptime)\nlog(){ echo "$(date \'+%F %T\') $*" >> "$LOG"; [ $TESTE = 1 ] && echo "$*"; tail -n 300 "$LOG" > "$LOG.tmp" 2>/dev/null && mv "$LOG.tmp" "$LOG"; }\nGW=$(ip route 2>/dev/null | awk \'/^default/{print $3; exit}\')\nCABO=$(cat /sys/class/net/en*/carrier 2>/dev/null | head -n1)\nnet_ok(){\n  ping -c2 -W3 1.1.1.1 >/dev/null 2>&1 && return 0\n  ping -c2 -W3 8.8.8.8 >/dev/null 2>&1 && return 0\n  timeout 5 bash -c \'</dev/tcp/18.228.252.149/8000\' >/dev/null 2>&1 && return 0\n  return 1\n}\ngw_ok(){ [ -n "$GW" ] && ping -c3 -W2 "$GW" >/dev/null 2>&1; }\n\nif net_ok; then\n  [ -s "$EST/falhas" ] && log "internet voltou (depois de $(cat "$EST/falhas") falha(s))"\n  rm -f "$EST/falhas"; [ $TESTE = 1 ] && echo "OK: internet funcionando (gateway ${GW:-?}, cabo=${CABO:-?})"; exit 0\nfi\nif gw_ok; then\n  log "internet FORA, mas gateway $GW responde -> operadora/antena (nao reinicio nada)"\n  rm -f "$EST/falhas"; exit 0\nfi\nn=$(( $(cat "$EST/falhas" 2>/dev/null || echo 0) + 1 )); echo $n > "$EST/falhas"\nlog "SEM REDE no NUC (falha $n): gateway=${GW:-nenhum} cabo=${CABO:-?} uptime=${up}s"\n[ $TESTE = 1 ] && { echo "(modo teste: nao executo nada)"; exit 0; }\nif [ $n -eq 2 ] || [ $n -eq 3 ]; then\n  log "reiniciando a rede (systemd-networkd)"; sudo -n systemctl restart systemd-networkd >/dev/null 2>&1\nfi\nif [ $n -ge 4 ] && [ "$up" -gt 1200 ]; then\n  ult=$(cat "$EST/ultimo_reboot" 2>/dev/null || echo 0)\n  hoje=$(date +%F); qtd=$(grep -c "^$hoje .*REINICIANDO O NUC" "$LOG" 2>/dev/null)\n  if [ $((agora - ult)) -gt 7200 ] && [ "${qtd:-0}" -lt 4 ]; then\n    echo "$agora" > "$EST/ultimo_reboot"; rm -f "$EST/falhas"\n    log "REINICIANDO O NUC (sem rede ha ~$((n*5)) min)"; sync; sudo -n systemctl reboot\n  fi\nfi\n'

_iniciado = False


def _sh(args, entrada=None, timeout=30):
    try:
        r = subprocess.run(args, input=entrada, capture_output=True, text=True, timeout=timeout)
        return r.returncode, (r.stdout or "") + (r.stderr or "")
    except Exception as e:
        return 99, str(e)


def _gravar_se_diferente(caminho, conteudo, executavel=False):
    try:
        with open(caminho, encoding="utf-8") as f:
            if f.read() == conteudo:
                return "igual"
    except Exception:
        pass
    if caminho.endswith(".py"):
        compile(conteudo, caminho, "exec")  # nunca grava um coletor quebrado
    tmp = caminho + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(conteudo)
        f.flush()
        os.fsync(f.fileno())
    if executavel:
        os.chmod(tmp, 0o755)
    os.replace(tmp, caminho)
    return "gravado"


def _linhas_cron():
    coletor = os.path.join(APP, "exa_saude.py")
    vigia = os.path.join(APP, "exa_vigia_rede.sh")
    return {
        "exa_saude.py": "*/15 * * * * cd %s && flock -n /tmp/exa_saude.lock timeout 90 nice -n 19 ionice -c3 python3 %s >/tmp/exa_saude.log 2>&1" % (APP, coletor),
        "exa_vigia_rede.sh": "*/5 * * * * flock -n /tmp/exa_vigia.lock timeout 120 bash %s >/dev/null 2>&1" % vigia,
    }


def _garantir_crontab():
    rc, saida = _sh(["crontab", "-l"])
    atuais = [l for l in saida.splitlines() if l.strip()] if rc == 0 else []
    queremos = _linhas_cron()
    novas = [l for l in atuais if not any(k in l for k in queremos)] + list(queremos.values())
    if novas == atuais:
        return "ok"
    rc, saida = _sh(["crontab", "-"], entrada="\n".join(novas) + "\n")
    if rc != 0:
        raise RuntimeError("crontab: " + saida.strip()[:120])
    rc, conf = _sh(["crontab", "-l"])
    falta = [k for k in queremos if k not in conf]
    if falta:
        raise RuntimeError("crontab nao gravou: " + ",".join(falta))
    return "gravado"


def _garantir_bloqueios():
    pendentes = []
    for u in BLOQUEAR:
        rc, est = _sh(["systemctl", "is-enabled", u], timeout=10)
        est = est.strip()
        if est == "masked" or "not-found" in est or "No such file" in est:
            continue
        rc, _ = _sh(["sudo", "-n", "systemctl", "mask", u], timeout=20)
        if rc != 0:
            pendentes.append(u)
    _sh(["pkill", "-f", "update-manager"], timeout=5)
    if pendentes:
        raise RuntimeError("sem permissao para bloquear: " + ",".join(pendentes))
    return "ok"


def garantir(cliente_id):
    # main.py e atualizador.py carregam o sistema; só um processo por vez faz o trabalho
    try:
        trava = open("/tmp/exa_padrao.lock", "w")
        fcntl.flock(trava, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except Exception:
        return {"ok": None, "pulado": "outro processo esta garantindo o padrao agora"}
    try:
        return _garantir(cliente_id)
    finally:
        try:
            fcntl.flock(trava, fcntl.LOCK_UN)
            trava.close()
        except Exception:
            pass


def _garantir(cliente_id):
    itens, erros = {}, {}
    cid = str(cliente_id or "").strip()
    if not cid or cid == "101":
        erros["tela"] = "codigo da tela desconhecido (%r)" % cid
    else:
        try:
            atual = {}
            try:
                with open(CONF_SAUDE, encoding="utf-8") as f:
                    atual = json.load(f)
            except Exception:
                pass
            if atual.get("cliente_id") != cid:
                atual["cliente_id"] = cid
                _gravar_se_diferente(CONF_SAUDE, json.dumps(atual))
            itens["tela"] = cid
        except Exception as e:
            erros["tela"] = str(e)[:150]
    mudou_coletor = False
    for nome, conteudo, exe in (("exa_saude.py", COLETOR, False), ("exa_vigia_rede.sh", VIGIA, True)):
        try:
            r = _gravar_se_diferente(os.path.join(APP, nome), conteudo, exe)
            itens[nome] = r
            if nome == "exa_saude.py" and r == "gravado":
                mudou_coletor = True
        except Exception as e:
            erros[nome] = str(e)[:150]
    for nome, fn in (("bloqueios", _garantir_bloqueios), ("agendamentos", _garantir_crontab)):
        try:
            itens[nome] = fn()
        except Exception as e:
            erros[nome] = str(e)[:150]
    anterior = {}
    try:
        with open(ESTADO, encoding="utf-8") as f:
            anterior = json.load(f)
    except Exception:
        pass
    estado = {"versao": VERSAO, "quando": time.strftime("%Y-%m-%d %H:%M:%S"), "ok": not erros,
              "itens": itens, "erros": erros, "primeira_leitura": anterior.get("primeira_leitura")}
    if "tela" in itens and (mudou_coletor or anterior.get("versao") != VERSAO):
        try:  # primeira leitura agora, para o sistema ver o NUC sem esperar 15 min
            subprocess.Popen(["nice", "-n", "19", "timeout", "90", "python3", os.path.join(APP, "exa_saude.py")],
                             cwd=APP, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
            estado["primeira_leitura"] = estado["quando"]
        except Exception as e:
            erros["primeira_leitura"] = str(e)[:150]
    try:
        _gravar_se_diferente(ESTADO, json.dumps(estado, ensure_ascii=False))
    except Exception:
        pass
    return estado


def _laco(cliente_id, atraso, intervalo):
    time.sleep(atraso)
    while True:
        try:
            e = garantir(cliente_id)
            print("Padrao EXA %s: %s" % (VERSAO, "OK" if e.get("ok") else "PENDENTE %s" % e.get("erros")))
        except Exception as ex:
            print("Padrao EXA falhou: %s" % ex)
        time.sleep(intervalo)


def iniciar(cliente_id, atraso=60, intervalo=6 * 3600):
    global _iniciado
    if _iniciado:
        return
    _iniciado = True
    threading.Thread(target=_laco, args=(cliente_id, atraso, intervalo), daemon=True).start()
