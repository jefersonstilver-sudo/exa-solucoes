# -*- coding: utf-8 -*-
"""
EXA 2.0 — player v10: o próprio player garante o "padrão EXA" no NUC (sem terminal, via OTA).

Roda em segundo plano dentro do atualizador (thread daemon), 60 s depois de iniciar e depois a cada 6 h:
  1. ~/.exa_saude.json com o código da tela (tela_id do player)
  2. coletor de saúde (exa_saude.py) e vigia de rede (exa_vigia_rede.sh) — regrava só se mudou
  3. bloqueios: desligamento programado (poweroff/halt), packagekit e atualizações automáticas do apt
  4. agendamentos no crontab do usuário (coletor a cada 15 min, vigia a cada 5 min), preservando as outras linhas
  5. primeira leitura do coletor logo após instalar/atualizar
  6. registra o resultado em ~/.exa_padrao.json (o coletor envia isso ao sistema)
Nunca levanta exceção para fora, nunca para nem reinicia o player.
"""
import fcntl
import json
import os
import subprocess
import threading
import time

VERSAO = "padrao-v5"
APP = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
HOME = os.path.expanduser("~")
ESTADO = os.path.join(HOME, ".exa_padrao.json")
CONF_SAUDE = os.path.join(HOME, ".exa_saude.json")
BLOQUEAR = ["poweroff.target", "halt.target", "packagekit.service", "apt-daily.timer",
            "apt-daily-upgrade.timer", "update-notifier-download.timer", "update-notifier-motd.timer"]

COLETOR = '# -*- coding: utf-8 -*-\n"""\nEXA 2.0 — Coletor de saúde do NUC ("auditoria v7", automática).\n\nRoda a cada 15 min pelo cron do usuário (instalado por instalar_saude_no_nuc.sh), SEPARADO do player:\n  - só LÊ o sistema (nada é alterado, nada é reiniciado);\n  - prioridade mínima de CPU e disco (nice 19 / ionice idle) e limite total de 150 s (timeout no cron);\n  - cada medição tem limite próprio; se uma falhar, as outras seguem;\n  - se a internet estiver fora, apenas não envia (tenta de novo no próximo ciclo).\n\nEnvia para o ExaSistema (função telas_registrar_saude), a mesma porta que o player usa para o heartbeat.\nO teste de velocidade de download (5 MB) roda só 1x por dia.\n"""\nimport json\nimport os\nimport re\nimport shutil\nimport socket\nimport subprocess\nimport sys\nimport time\nimport urllib.request\n\nAPP = os.path.expanduser("~/Documentos/appUbuntu")\nCONF = os.path.expanduser("~/.exa_saude.json")      # {"cliente_id": "bc17"} gravado na instalação\nESTADO = os.path.expanduser("~/.exa_saude_estado.json")\nVERSAO_COLETOR = "saude-v7.1"\nAPI_TELAS = "18.228.252.149"\nURL_VEL_S3 = "https://sistema-update.s3.sa-east-1.amazonaws.com/diag/velocidade_5mb.bin"\nURL_VEL_CF = "https://speed.cloudflare.com/__down?bytes=5000000"\n\n\ndef sh(cmd, timeout=8, env=None):\n    try:\n        r = subprocess.run(cmd, shell=True, capture_output=True, text=True, timeout=timeout, env=env)\n        return r.stdout.strip()\n    except Exception:\n        return ""\n\n\ndef ler(caminho, padrao=""):\n    try:\n        with open(caminho) as f:\n            return f.read().strip()\n    except Exception:\n        return padrao\n\n\ndef env_do_player():\n    vals = {}\n    for linha in ler(os.path.join(APP, ".env")).splitlines():\n        linha = linha.strip()\n        if not linha or linha.startswith("#") or "=" not in linha:\n            continue\n        k, v = linha.split("=", 1)\n        vals[k.strip()] = v.strip().strip(\'"\').strip("\'")\n    return vals\n\n\ndef temperatura():\n    melhor = None\n    for zona in sorted(os.listdir("/sys/class/thermal")) if os.path.isdir("/sys/class/thermal") else []:\n        if not zona.startswith("thermal_zone"):\n            continue\n        t = ler("/sys/class/thermal/%s/temp" % zona)\n        tipo = ler("/sys/class/thermal/%s/type" % zona)\n        try:\n            c = int(t) / 1000.0\n        except Exception:\n            continue\n        if 5 < c < 125 and (melhor is None or c > melhor[0]):\n            melhor = (c, tipo)\n    if melhor is None:\n        out = sh("sensors 2>/dev/null")\n        nums = [float(x) for x in re.findall(r"\\+(\\d+\\.\\d)°C", out)]\n        if nums:\n            melhor = (max(nums), "sensors")\n    return (round(melhor[0], 1), melhor[1]) if melhor else (None, None)\n\n\ndef memoria():\n    info = {}\n    for linha in ler("/proc/meminfo").splitlines():\n        p = linha.split()\n        if len(p) >= 2:\n            info[p[0].rstrip(":")] = int(p[1])\n    tot, disp = info.get("MemTotal", 0), info.get("MemAvailable", 0)\n    st, sf = info.get("SwapTotal", 0), info.get("SwapFree", 0)\n    return {\n        "ram_total_gb": round(tot / 1048576, 1) if tot else None,\n        "ram_uso_pct": round(100 * (tot - disp) / tot) if tot else None,\n        "swap_uso_pct": round(100 * (st - sf) / st) if st else 0,\n    }\n\n\ndef ping(host, n=10):\n    out = sh("ping -n -q -c %d -i 0.3 -W 1 %s 2>/dev/null" % (n, host), timeout=n + 6)\n    perda = re.search(r"(\\d+(?:\\.\\d+)?)% packet loss", out)\n    rtt = re.search(r"= ([\\d.]+)/([\\d.]+)/([\\d.]+)/([\\d.]+) ms", out)\n    return {\n        "perda_pct": float(perda.group(1)) if perda else 100.0,\n        "lat_ms": float(rtt.group(2)) if rtt else None,\n        "lat_max_ms": float(rtt.group(3)) if rtt else None,\n        "jitter_ms": float(rtt.group(4)) if rtt else None,\n    }\n\n\ndef tcp(host, porta, n=5):\n    """Servidor das telas não responde ping (firewall da AWS): mede abrindo conexão na porta da API."""\n    tempos, falhas = [], 0\n    for _ in range(n):\n        t0 = time.time()\n        try:\n            c = socket.create_connection((host, porta), timeout=3)\n            c.close()\n            tempos.append((time.time() - t0) * 1000)\n        except Exception:\n            falhas += 1\n        time.sleep(0.2)\n    return {\n        "perda_pct": round(100.0 * falhas / n, 1),\n        "lat_ms": round(sum(tempos) / len(tempos), 1) if tempos else None,\n        "lat_max_ms": round(max(tempos), 1) if tempos else None,\n        "metodo": "tcp",\n    }\n\n\ndef rede():\n    d = {}\n    rota = sh("ip -4 route show default 2>/dev/null").splitlines()\n    m = re.search(r"default via (\\S+) dev (\\S+)", rota[0]) if rota else None\n    if not m:\n        d["sem_rota"] = True\n        return d\n    gw, iface = m.group(1), m.group(2)\n    d["gateway"], d["iface"] = gw, iface\n    sem_fio = os.path.isdir("/sys/class/net/%s/wireless" % iface) or os.path.exists("/sys/class/net/%s/phy80211" % iface)\n    d["tipo"] = "wifi" if sem_fio else "cabo"\n    vel = ler("/sys/class/net/%s/speed" % iface)\n    if vel.lstrip("-").isdigit() and int(vel) > 0:\n        d["link_mbps"] = int(vel)\n    if sem_fio:\n        lk = sh("iw dev %s link 2>/dev/null" % iface)\n        f = re.search(r"freq: (\\d+)", lk)\n        s = re.search(r"signal: (-?\\d+) dBm", lk)\n        b = re.search(r"tx bitrate: ([\\d.]+) MBit", lk)\n        ss = re.search(r"SSID: (.+)", lk)\n        if f:\n            mhz = int(f.group(1))\n            d["wifi_mhz"] = mhz\n            d["wifi_banda"] = "5 GHz" if mhz >= 4900 else "2.4 GHz"\n        if s:\n            d["wifi_sinal_dbm"] = int(s.group(1))\n        if b:\n            d["wifi_taxa_mbps"] = float(b.group(1))\n        if ss:\n            d["wifi_ssid"] = ss.group(1).strip()[:40]\n    d["gw"] = ping(gw)\n    d["internet"] = ping("8.8.8.8")\n    d["api_telas"] = tcp(API_TELAS, 8000)\n    try:\n        with urllib.request.urlopen("https://api.ipify.org", timeout=6) as r:\n            d["ip_publico"] = r.read(64).decode().strip()\n    except Exception:\n        pass\n    try:\n        socket.setdefaulttimeout(5)\n        socket.gethostbyname("iwlscwsenzgyylopnwpu.supabase.co")\n        d["dns_ok"] = True\n    except Exception:\n        d["dns_ok"] = False\n    return d\n\n\ndef _baixar_medindo(url, limite_s):\n    t0 = time.time()\n    n = 0\n    req = urllib.request.Request(url, headers={"User-Agent": "exa-saude"})\n    with urllib.request.urlopen(req, timeout=8) as r:\n        while time.time() - t0 < limite_s:\n            bloco = r.read(65536)\n            if not bloco:\n                break\n            n += len(bloco)\n    seg = max(time.time() - t0, 0.001)\n    return round(n * 8 / seg / 1e6, 2), n, round(seg, 1)\n\n\ndef velocidade_download(estado):\n    """v7: mede do NOSSO S3 (de onde vêm os vídeos) e da Cloudflare (referência). No máx. 1x a cada 6 h; 15 s cada."""\n    if estado.get("velocidade") and time.time() - estado.get("ultimo_speedtest", 0) < 6 * 3600:\n        return estado.get("velocidade")\n    d = {}\n    for nome, url in (("s3", URL_VEL_S3), ("cloudflare", URL_VEL_CF)):\n        try:\n            mbps, n, seg = _baixar_medindo(url, 15)\n            d[nome] = {"mbps": mbps, "bytes": n, "seg": seg}\n        except Exception as e:\n            d[nome] = {"erro": str(e)[:80]}\n    d["medido_em"] = time.strftime("%Y-%m-%d %H:%M")\n    estado["ultimo_speedtest"] = time.time() if any("mbps" in v for v in d.values() if isinstance(v, dict)) else time.time() - 5 * 3600\n    estado["velocidade"] = d\n    return d\n\n\ndef monitor():\n    env = dict(os.environ)\n    env.setdefault("DISPLAY", ":0")\n    env.setdefault("XAUTHORITY", os.path.expanduser("~/.Xauthority"))\n    d = {}\n    xr = sh("xrandr --query 2>/dev/null", timeout=6, env=env)\n    if xr:\n        conectadas = re.findall(r"^(\\S+) connected(?: primary)? (\\d+x\\d+)?", xr, re.M)\n        d["saidas_conectadas"] = [c[0] for c in conectadas]\n        d["resolucao"] = next((c[1] for c in conectadas if c[1]), None)\n        d["monitor_conectado"] = bool(conectadas)\n    xs = sh("xset q 2>/dev/null", timeout=6, env=env)\n    if "Monitor is" in xs:\n        d["monitor_ligado"] = "Monitor is On" in xs\n    return d\n\n\ndef tela(resolucao):\n    """v7: duas capturas pequenas da tela com 3 s de intervalo. Igual = possivelmente CONGELADA\n    (o relógio da tela mostra segundos, então uma tela viva sempre muda). Brilho ~0 = tela PRETA."""\n    if not shutil.which("ffmpeg"):\n        return {"metodo": "sem ffmpeg"}\n    env = dict(os.environ)\n    env.setdefault("DISPLAY", ":0")\n    env.setdefault("XAUTHORITY", os.path.expanduser("~/.Xauthority"))\n    tam = resolucao or "1080x1920"\n\n    def foto():\n        r = subprocess.run(["nice", "-n", "19", "ffmpeg", "-loglevel", "error", "-f", "x11grab", "-video_size", tam, "-i",\n                            env["DISPLAY"], "-frames:v", "1", "-vf", "scale=48:-1", "-pix_fmt", "gray", "-f", "rawvideo", "-"],\n                           capture_output=True, timeout=12, env=env)\n        return r.stdout\n\n    a = foto()\n    time.sleep(3)\n    b = foto()\n    if not a or not b:\n        return {"erro": "captura falhou"}\n    dif = sum(1 for x, y in zip(a, b) if abs(x - y) > 8)\n    return {"mudou": dif > 0, "pixels_mudaram": dif, "brilho": round(sum(b) / len(b), 1), "preta": sum(b) / len(b) < 4}\n\n\ndef motivo_boot(estado):\n    """v7: quando o NUC ligou de novo, descobre como a sessão anterior terminou (journal da sessão anterior)."""\n    bid = ler("/proc/sys/kernel/random/boot_id")\n    if not bid:\n        return estado.get("ultimo_boot")\n    if estado.get("boot_id") == bid:\n        return estado.get("ultimo_boot")\n    d = {"detectado_em": time.strftime("%Y-%m-%d %H:%M:%S")}\n    try:\n        d["ligou_em"] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time() - float(ler("/proc/uptime", "0").split()[0])))\n    except Exception:\n        pass\n    ant = sh("journalctl -b -1 -n 80 -o short-iso --no-pager 2>/dev/null", timeout=15)\n    if not ant:\n        d["tipo"] = "desconhecido (sem registro da sessao anterior)"\n    else:\n        linhas = [l for l in ant.splitlines() if l and not l.startswith("--")]\n        d["anterior_terminou"] = linhas[-1][:25] if linhas else None\n        if re.search(r"Reached target .*(Reboot|System Reboot)|systemd-shutdown.*reboot|Rebooting", ant, re.I):\n            d["tipo"] = "reinicio pelo sistema"\n        elif re.search(r"Reached target .*(Power-Off|Shutdown|Halt)|systemd-shutdown|Journal stopped|System is powering down", ant, re.I):\n            d["tipo"] = "desligamento pelo sistema"\n        else:\n            d["tipo"] = "abrupto (falta de energia ou travamento)"\n    vlog = ler(os.path.expanduser("~/.exa_vigia/vigia.log"))\n    if d.get("anterior_terminou") and "REINICIANDO O NUC" in vlog:\n        dia = d["anterior_terminou"][:10]\n        if any(l.startswith(dia) and "REINICIANDO O NUC" in l for l in vlog.splitlines()[-20:]):\n            d["tipo"] = "reiniciado pelo vigia (NUC sem rede)"\n    estado["boot_id"] = bid\n    estado["ultimo_boot"] = d\n    return d\n\n\ndef versao_player():\n    m = re.search(r\'APP_VERSAO\\s*=\\s*"([^"]+)"\', ler(os.path.join(APP, "atualizadores", "sistema.py")))\n    return m.group(1) if m else (ler(os.path.join(APP, "version_app.txt")) or None)\n\n\ndef cpu():\n    """Uso real de CPU em 2 s e os processos que mais consomem (explica carga alta)."""\n    def amostra():\n        v = [int(x) for x in ler("/proc/stat").splitlines()[0].split()[1:]]\n        ocioso = v[3] + (v[4] if len(v) > 4 else 0)\n        return sum(v), ocioso\n    try:\n        t1, o1 = amostra()\n        time.sleep(2)\n        t2, o2 = amostra()\n        uso = round(100 * (1 - (o2 - o1) / max(t2 - t1, 1)))\n    except Exception:\n        uso = None\n    top = []\n    for linha in sh("ps -eo pcpu,pmem,comm --sort=-pcpu --no-headers 2>/dev/null | head -n 5").splitlines():\n        p = linha.split(None, 2)\n        if len(p) == 3:\n            top.append({"cpu": float(p[0]), "mem": float(p[1]), "proc": p[2][:30]})\n    io = sh("cat /proc/pressure/io 2>/dev/null | head -n1")\n    m = re.search(r"avg60=([\\d.]+)", io)\n    return {"cpu_uso_pct": uso, "top": top, "io_espera_pct": float(m.group(1)) if m else None}\n\n\ndef player():\n    procs = sh("pgrep -af \'python\' 2>/dev/null")\n    d = {\n        "main_rodando": "main.py" in procs,\n        "atualizador_rodando": "atualizador.py" in procs,\n        "app_versao": versao_player(),\n    }\n    pid = sh("pgrep -of \'main.py\'")\n    if pid.isdigit():\n        et = sh("ps -o etimes= -p %s" % pid)\n        if et.strip().isdigit():\n            d["main_ha_min"] = int(et) // 60\n    pasta = os.path.join(APP, "cache", "Propagandas")\n    try:\n        arqs = [f for f in os.listdir(pasta) if not f.endswith(".part")]\n        d["videos_no_cache"] = len(arqs)\n        d["cache_mb"] = round(sum(os.path.getsize(os.path.join(pasta, f)) for f in arqs) / 1048576)\n    except Exception:\n        pass\n    # disco aceita escrita? (disco "somente leitura" trava o player sem avisar)\n    teste = os.path.join(APP, ".exa_saude_teste")\n    try:\n        with open(teste, "w") as f:\n            f.write("ok")\n        os.remove(teste)\n        d["disco_gravavel"] = True\n    except Exception:\n        d["disco_gravavel"] = False\n    return d\n\n\ndef sistema():\n    d = {}\n    try:\n        d["uptime_h"] = round(float(ler("/proc/uptime", "0").split()[0]) / 3600, 1)\n    except Exception:\n        pass\n    try:\n        d["load1"] = round(os.getloadavg()[0], 2)\n    except Exception:\n        pass\n    d["cores"] = os.cpu_count()\n    du = shutil.disk_usage("/")\n    d["disco_total_gb"] = round(du.total / 1e9)\n    d["disco_uso_pct"] = round(100 * du.used / du.total)\n    d.update(memoria())\n    d["ntp_ok"] = sh("timedatectl show -p NTPSynchronized --value 2>/dev/null") == "yes"\n    # desligamento programado da 01:00 (cron do root): só é seguro com poweroff/halt mascarados\n    d["poweroff_mascarado"] = sh("systemctl is-enabled poweroff.target 2>/dev/null") == "masked"\n    boots = sh("journalctl --list-boots --no-pager 2>/dev/null | tail -n 30", timeout=10)\n    if boots:\n        agora = time.time()\n        n = 0\n        for linha in boots.splitlines():\n            m = re.search(r"(\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2})", linha)\n            if m:\n                try:\n                    t = time.mktime(time.strptime(m.group(1), "%Y-%m-%d %H:%M:%S"))\n                    if agora - t < 86400:\n                        n += 1\n                except Exception:\n                    pass\n        d["boots_24h"] = n\n    d["hostname"] = socket.gethostname()\n    d["produto"] = ler("/sys/class/dmi/id/product_name") or None\n    d["fabricante"] = ler("/sys/class/dmi/id/sys_vendor") or None\n    d["cpu"] = next((l.split(":", 1)[1].strip() for l in ler("/proc/cpuinfo").splitlines() if l.startswith("model name")), None)\n    return d\n\n\ndef vigia(estado):\n    """Vigia de rede: diário de conexão (mudanças de estado minuto a minuto) + ações + estado do cabo."""\n    d = {"instalado": "exa_vigia_rede.sh" in sh("crontab -l 2>/dev/null")}\n    base = os.path.expanduser("~/.exa_vigia/")\n    d["estado_agora"] = ler(base + "estado") or None\n    try:\n        d["falhas_agora_min"] = int(ler(base + "falhas", "0") or 0)\n    except Exception:\n        d["falhas_agora_min"] = 0\n    acoes = ler(base + "vigia.log").splitlines()\n    limite = time.strftime("%Y-%m-%d", time.localtime(time.time() - 7 * 86400))\n    rec = [l for l in acoes if l[:10] >= limite]\n    d["reboots_7d"] = sum("REINICIANDO O NUC" in l for l in rec)\n    d["rede_reiniciada_7d"] = sum("reiniciando a rede" in l for l in rec)\n    d["acoes"] = [l[:140] for l in rec[-6:]]\n    # diário: envia o que ainda não foi enviado (até 60 linhas) + resumo das últimas 24 h\n    diario = ler(base + "diario.log").splitlines()\n    ultimo = estado.get("diario_ultimo", "")\n    novos = [l for l in diario if l > ultimo] if ultimo else diario[-60:]\n    d["diario_novos"] = [l[:120] for l in novos[-60:]]\n    estado["_diario_pendente"] = diario[-1] if diario else ultimo\n    lim24 = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time() - 86400))\n    res = {}\n    for l in diario:\n        if l[:19] >= lim24:\n            tipo = (l[20:].split(" ") or ["?"])[0]\n            res[tipo] = res.get(tipo, 0) + 1\n    d["eventos_24h"] = res\n    for dev in sorted(os.listdir("/sys/class/net")):\n        if dev.startswith(("en", "eth")):\n            b = "/sys/class/net/" + dev\n            d["cabo"] = {"placa": dev, "sinal": ler(b + "/carrier") == "1", "velocidade_mbps": ler(b + "/speed") or None,\n                         "driver": os.path.basename(os.path.realpath(b + "/device/driver")) if os.path.exists(b + "/device/driver") else None,\n                         "erros_rx": ler(b + "/statistics/rx_errors") or None,\n                         "quedas_link": ler(b + "/carrier_changes") or None}\n            break\n    return d\n\n\ndef identidade():\n    """Um prédio pode ter 2+ NUCs com o mesmo código de tela: cada NUC se identifica pelo ID do AnyDesk\n    (o mesmo do painel de monitoramento) ou, sem ele, pelo machine-id."""\n    ad = sh("anydesk --get-id 2>/dev/null", timeout=8)\n    ad = ad if ad.isdigit() else ""\n    mid = ler("/etc/machine-id")[:12]\n    return ad, (ad or mid or socket.gethostname())\n\n\ndef enviar(payload, env):\n    url = (env.get("SUPABASE_URL") or "").rstrip("/")\n    chave = env.get("SUPABASE_KEY") or env.get("SUPABASE_ANON_KEY") or env.get("SUPABASE_SERVICE_KEY") or ""\n    if not url or not chave:\n        print("sem SUPABASE_URL/chave no .env do player")\n        return False\n    req = urllib.request.Request(\n        url + "/rest/v1/rpc/telas_registrar_saude",\n        data=json.dumps({"p": payload}).encode(),\n        headers={"apikey": chave, "Authorization": "Bearer " + chave, "Content-Type": "application/json"},\n        method="POST",\n    )\n    try:\n        with urllib.request.urlopen(req, timeout=15) as r:\n            if not 200 <= r.status < 300:\n                return False\n            corpo = r.read(300).decode("utf-8", "replace").strip().strip(\'"\')\n            # v7: o servidor (telas_registrar_saude v2) diz se gravou; versão antiga responde vazio = gravou\n            if corpo.startswith("ignorado"):\n                print("servidor recusou: %s" % corpo)\n                return False\n            return True\n    except Exception as e:\n        print("envio falhou: %s" % e)\n        return False\n\n\ndef main():\n    conf = {}\n    try:\n        conf = json.loads(ler(CONF, "{}"))\n    except Exception:\n        pass\n    cliente = conf.get("cliente_id")\n    if not cliente:\n        print("sem cliente_id em %s" % CONF)\n        return 1\n    estado = {}\n    try:\n        estado = json.loads(ler(ESTADO, "{}"))\n    except Exception:\n        pass\n    t, fonte = temperatura()\n    ad, nuc = identidade()\n    payload = {"cliente_id": cliente, "nuc_id": nuc, "anydesk_id": ad or None, "coletor": VERSAO_COLETOR,\n               "coletado_em": int(time.time()), "temp_c": t, "temp_fonte": fonte}\n    inicio = time.time()\n    tempos = {}\n    for nome, fn in (("sistema", sistema), ("cpu", cpu), ("rede", rede), ("monitor", monitor), ("player", player),\n                     ("vigia", lambda: vigia(estado)), ("boot", lambda: motivo_boot(estado)),\n                     ("tela", lambda: tela((payload.get("monitor") or {}).get("resolucao")))):\n        t0 = time.time()\n        try:\n            payload[nome] = fn()\n        except Exception as e:\n            payload[nome] = {"erro": str(e)[:120]}\n        tempos[nome] = round(time.time() - t0, 1)\n    # v6.1: o teste de velocidade só roda se ainda sobra tempo (o envio é o que importa)\n    if time.time() - inicio < 45:\n        t0 = time.time()\n        payload["velocidade"] = velocidade_download(estado)\n        tempos["velocidade"] = round(time.time() - t0, 1)\n    else:\n        payload["velocidade"] = estado.get("velocidade")\n        tempos["velocidade"] = "pulado"\n    v = payload.get("velocidade") or {}\n    payload["download_mbps"] = next((v[k]["mbps"] for k in ("s3", "cloudflare") if isinstance(v.get(k), dict) and "mbps" in v[k]), None)\n    payload["tempos_s"] = tempos\n    try:  # v10: o que o próprio player garantiu (padrão EXA)\n        pd = json.loads(ler(os.path.expanduser("~/.exa_padrao.json"), "{}"))\n        payload["padrao"] = {k: pd.get(k) for k in ("versao", "quando", "ok", "itens", "erros")}\n    except Exception:\n        pass\n    ok = enviar(payload, env_do_player())\n    if ok and estado.get("_diario_pendente"):\n        estado["diario_ultimo"] = estado["_diario_pendente"]  # só marca como enviado se o envio deu certo\n    estado.pop("_diario_pendente", None)\n    try:\n        with open(ESTADO, "w") as f:\n            json.dump(estado, f)\n    except Exception:\n        pass\n    if "--mostrar" in sys.argv:\n        print(json.dumps(payload, ensure_ascii=False, indent=1))\n    print("ENVIADO" if ok else "NAO ENVIADO")\n    return 0\n\n\nif __name__ == "__main__":\n    sys.exit(main())\n'

VIGIA = '#!/bin/bash\n# EXA 2.0 — vigia de rede (vigia-v2). Roda pelo crontab do usuário exa a CADA MINUTO.\n# 1) DIÁRIO DE CONEXÃO (~/.exa_vigia/diario.log): grava cada MUDANÇA de estado, com hora, mesmo sem internet.\n#    O coletor envia o diário quando a conexão volta -> cada queda chega explicada:\n#      OK           internet funcionando\n#      OPERADORA    cabo ok, roteador responde, internet não  -> operadora / link do prédio\n#      SEM_GATEWAY  cabo com sinal, roteador não responde     -> roteador/antena/rede local (ou placa do NUC)\n#      SEM_CABO     placa sem sinal no cabo                    -> antena/PoE desligada, cabo, ou placa do NUC\n#      SEM_ROTA     sem endereço/rota configurada              -> rede do NUC não subiu\n#      BOOT         NUC ligou (anterior_visto = último minuto em que o vigia viu o NUC vivo antes)\n# 2) RECUPERAÇÃO (caso Foz Residence 23/10: placa Realtek não subiu no boot, 5 dias mudo):\n#    falha do lado do NUC (SEM_GATEWAY/SEM_CABO/SEM_ROTA) por 10 min -> reinicia a rede;\n#    por 20 min -> reinicia o NUC (máx. 1x a cada 2 h e 4x por dia; só se ligado há > 20 min).\n#    OPERADORA nunca reinicia nada (não adiantaria).\n# Teste sem agir:  bash exa_vigia_rede.sh --teste\nEST="$HOME/.exa_vigia"; mkdir -p "$EST"; LOG="$EST/vigia.log"; DIA="$EST/diario.log"\nTESTE=0; [ "$1" = "--teste" ] && TESTE=1\nagora=$(date +%s); up=$(cut -d. -f1 /proc/uptime)\ncorta(){ [ -f "$1" ] && [ "$(wc -l < "$1")" -gt "$2" ] && tail -n "$2" "$1" > "$1.tmp" && mv "$1.tmp" "$1"; }\nlog(){ echo "$(date \'+%F %T\') $*" >> "$LOG"; [ $TESTE = 1 ] && echo "acao: $*"; corta "$LOG" 300; }\ndiario(){ echo "$(date \'+%F %T\') $*" >> "$DIA"; [ $TESTE = 1 ] && echo "diario: $*"; corta "$DIA" 3000; }\n\n# NUC ligou?\nBID=$(cat /proc/sys/kernel/random/boot_id 2>/dev/null)\nif [ -n "$BID" ] && [ "$(cat "$EST/boot_id" 2>/dev/null)" != "$BID" ]; then\n  ant=$(cat "$EST/visto" 2>/dev/null)\n  if [ -f "$EST/boot_id" ]; then\n    diario "BOOT uptime=${up}s anterior_visto=$( [ -n "$ant" ] && date -d @"$ant" \'+%F %T\' || echo \'?\')"\n  else\n    diario "INICIO_DIARIO uptime=${up}s"   # primeira execução do vigia-v2 neste NUC (não é religamento)\n  fi\n  echo "$BID" > "$EST/boot_id"; rm -f "$EST/estado" "$EST/falhas"\nfi\n\nGW=$(ip route 2>/dev/null | awk \'/^default/{print $3; exit}\')\nCABO=$(cat /sys/class/net/en*/carrier 2>/dev/null | head -n1)\nnet_ok(){\n  ping -c1 -W2 1.1.1.1 >/dev/null 2>&1 && return 0\n  ping -c1 -W2 8.8.8.8 >/dev/null 2>&1 && return 0\n  timeout 5 bash -c \'</dev/tcp/18.228.252.149/8000\' >/dev/null 2>&1 && return 0\n  return 1\n}\ngw_ok(){ [ -n "$GW" ] && { ping -c2 -W2 "$GW" >/dev/null 2>&1 || ping -c2 -W2 "$GW" >/dev/null 2>&1; }; }\n\nif net_ok; then ESTADO=OK\nelif [ "$CABO" = "0" ]; then ESTADO=SEM_CABO\nelif [ -z "$GW" ]; then ESTADO=SEM_ROTA\nelif gw_ok; then ESTADO=OPERADORA\nelse ESTADO=SEM_GATEWAY; fi\necho "$agora" > "$EST/visto"\n\nANT=$(cat "$EST/estado" 2>/dev/null)\nif [ "$ESTADO" != "$ANT" ]; then\n  diario "$ESTADO cabo=${CABO:-?} gw=${GW:-nenhum}"\n  echo "$ESTADO" > "$EST/estado"\nfi\n[ $TESTE = 1 ] && echo "estado: $ESTADO (cabo=${CABO:-?} gateway=${GW:-nenhum} uptime=${up}s)"\n\ncase "$ESTADO" in\n  OK|OPERADORA) rm -f "$EST/falhas"; exit 0 ;;\nesac\nn=$(( $(cat "$EST/falhas" 2>/dev/null || echo 0) + 1 )); echo $n > "$EST/falhas"\n[ $TESTE = 1 ] && { echo "(modo teste: nao executo nada; falha do NUC ha $n min)"; exit 0; }\nif [ $n -eq 10 ] || [ $n -eq 15 ]; then\n  log "SEM REDE no NUC ha $n min ($ESTADO): reiniciando a rede (systemd-networkd)"\n  sudo -n systemctl restart systemd-networkd >/dev/null 2>&1\nfi\nif [ $n -ge 20 ] && [ "$up" -gt 1200 ]; then\n  ult=$(cat "$EST/ultimo_reboot" 2>/dev/null || echo 0)\n  hoje=$(date +%F); qtd=$(grep -c "^$hoje .*REINICIANDO O NUC" "$LOG" 2>/dev/null)\n  if [ $((agora - ult)) -gt 7200 ] && [ "${qtd:-0}" -lt 4 ]; then\n    echo "$agora" > "$EST/ultimo_reboot"; rm -f "$EST/falhas"\n    log "REINICIANDO O NUC (sem rede ha $n min, $ESTADO)"; diario "VIGIA_REINICIOU_NUC $ESTADO ha $n min"\n    sync; sudo -n systemctl reboot\n  fi\nfi\n'

_iniciado = False
_CARREGADO_EM = time.time()  # v11.1: o sistema recarrega a peça quando o arquivo no disco é mais novo


def _sh(args, entrada=None, timeout=30):
    try:
        r = subprocess.run(args, input=entrada, capture_output=True, text=True, timeout=timeout)
        return r.returncode, (r.stdout or "") + (r.stderr or "")
    except Exception as e:
        return 99, str(e)


def _gravar_se_diferente(caminho, conteudo, executavel=False):
    try:
        with open(caminho, encoding="utf-8") as f:
            if f.read() == conteudo:
                return "igual"
    except Exception:
        pass
    if caminho.endswith(".py"):
        compile(conteudo, caminho, "exec")  # nunca grava um coletor quebrado
    tmp = caminho + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(conteudo)
        f.flush()
        os.fsync(f.fileno())
    if executavel:
        os.chmod(tmp, 0o755)
    os.replace(tmp, caminho)
    return "gravado"


def _linhas_cron():
    coletor = os.path.join(APP, "exa_saude.py")
    vigia = os.path.join(APP, "exa_vigia_rede.sh")
    return {
        "exa_saude.py": "*/15 * * * * cd %s && flock -n /tmp/exa_saude.lock timeout 150 nice -n 19 ionice -c3 python3 %s >/tmp/exa_saude.log 2>&1" % (APP, coletor),
        "exa_vigia_rede.sh": "* * * * * flock -n /tmp/exa_vigia.lock timeout 50 bash %s >/dev/null 2>&1" % vigia,
    }


def _garantir_crontab():
    rc, saida = _sh(["crontab", "-l"])
    atuais = [l for l in saida.splitlines() if l.strip()] if rc == 0 else []
    queremos = _linhas_cron()
    novas = [l for l in atuais if not any(k in l for k in queremos)] + list(queremos.values())
    if novas == atuais:
        return "ok"
    rc, saida = _sh(["crontab", "-"], entrada="\n".join(novas) + "\n")
    if rc != 0:
        raise RuntimeError("crontab: " + saida.strip()[:120])
    rc, conf = _sh(["crontab", "-l"])
    falta = [k for k in queremos if k not in conf]
    if falta:
        raise RuntimeError("crontab nao gravou: " + ",".join(falta))
    return "gravado"


def _garantir_bloqueios():
    pendentes = []
    for u in BLOQUEAR:
        rc, est = _sh(["systemctl", "is-enabled", u], timeout=10)
        est = est.strip()
        if est == "masked" or "not-found" in est or "No such file" in est:
            continue
        rc, _ = _sh(["sudo", "-n", "systemctl", "mask", u], timeout=20)
        if rc != 0:
            pendentes.append(u)
    _sh(["pkill", "-f", "update-manager"], timeout=5)
    if pendentes:
        raise RuntimeError("sem permissao para bloquear: " + ",".join(pendentes))
    return "ok"


def garantir(cliente_id):
    # main.py e atualizador.py carregam o sistema; só um processo por vez faz o trabalho
    try:
        trava = open("/tmp/exa_padrao.lock", "w")
        fcntl.flock(trava, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except Exception:
        return {"ok": None, "pulado": "outro processo esta garantindo o padrao agora"}
    try:
        return _garantir(cliente_id)
    finally:
        try:
            fcntl.flock(trava, fcntl.LOCK_UN)
            trava.close()
        except Exception:
            pass


def _garantir(cliente_id):
    itens, erros = {}, {}
    cid = str(cliente_id or "").strip()
    if not cid or cid == "101":
        erros["tela"] = "codigo da tela desconhecido (%r)" % cid
    else:
        try:
            atual = {}
            try:
                with open(CONF_SAUDE, encoding="utf-8") as f:
                    atual = json.load(f)
            except Exception:
                pass
            if atual.get("cliente_id") != cid:
                atual["cliente_id"] = cid
                _gravar_se_diferente(CONF_SAUDE, json.dumps(atual))
            itens["tela"] = cid
        except Exception as e:
            erros["tela"] = str(e)[:150]
    mudou_coletor = False
    for nome, conteudo, exe in (("exa_saude.py", COLETOR, False), ("exa_vigia_rede.sh", VIGIA, True)):
        try:
            r = _gravar_se_diferente(os.path.join(APP, nome), conteudo, exe)
            itens[nome] = r
            if nome == "exa_saude.py" and r == "gravado":
                mudou_coletor = True
        except Exception as e:
            erros[nome] = str(e)[:150]
    for nome, fn in (("bloqueios", _garantir_bloqueios), ("agendamentos", _garantir_crontab)):
        try:
            itens[nome] = fn()
        except Exception as e:
            erros[nome] = str(e)[:150]
    anterior = {}
    try:
        with open(ESTADO, encoding="utf-8") as f:
            anterior = json.load(f)
    except Exception:
        pass
    estado = {"versao": VERSAO, "quando": time.strftime("%Y-%m-%d %H:%M:%S"), "ok": not erros,
              "itens": itens, "erros": erros, "primeira_leitura": anterior.get("primeira_leitura")}
    if "tela" in itens and (mudou_coletor or anterior.get("versao") != VERSAO):
        try:  # primeira leitura agora, para o sistema ver o NUC sem esperar 15 min
            subprocess.Popen(["nice", "-n", "19", "timeout", "150", "python3", os.path.join(APP, "exa_saude.py")],
                             cwd=APP, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
            estado["primeira_leitura"] = estado["quando"]
        except Exception as e:
            erros["primeira_leitura"] = str(e)[:150]
    try:
        _gravar_se_diferente(ESTADO, json.dumps(estado, ensure_ascii=False))
    except Exception:
        pass
    return estado


def _laco(cliente_id, atraso, intervalo):
    time.sleep(atraso)
    while True:
        try:
            e = garantir(cliente_id)
            print("Padrao EXA %s: %s" % (VERSAO, "OK" if e.get("ok") else "PENDENTE %s" % e.get("erros")))
        except Exception as ex:
            print("Padrao EXA falhou: %s" % ex)
        time.sleep(intervalo)


def iniciar(cliente_id, atraso=60, intervalo=6 * 3600):
    global _iniciado
    if _iniciado:
        return
    _iniciado = True
    threading.Thread(target=_laco, args=(cliente_id, atraso, intervalo), daemon=True).start()
